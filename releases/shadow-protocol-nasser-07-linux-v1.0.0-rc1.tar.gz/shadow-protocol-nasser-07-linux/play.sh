#!/usr/bin/env bash
# SHADOW PROTOCOL: NASSER 07 - Linux launcher
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo '  Node.js is required to serve the game (browsers refuse to load'
  echo '  3D assets from a local file:// page).'
  echo ''
  echo '    Debian/Ubuntu : sudo apt install nodejs'
  echo '    Fedora        : sudo dnf install nodejs'
  echo '    Arch          : sudo pacman -S nodejs'
  echo ''
  echo '  Then run ./play.sh again.'
  exit 1
fi

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "  Node $NODE_MAJOR is too old; version 18 or newer is required."
  exit 1
fi

exec node serve.mjs

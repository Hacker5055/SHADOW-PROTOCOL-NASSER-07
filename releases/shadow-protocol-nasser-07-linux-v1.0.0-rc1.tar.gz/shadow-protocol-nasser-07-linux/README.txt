SHADOW PROTOCOL: NASSER 07
Playable vertical slice - Linux build
=====================================

KEEP THIS FOLDER TOGETHER. It is not a single file: the game loads its
character and weapon models over http, so it needs the dist/ folder next to
the launcher.


REQUIREMENTS
------------
  * Linux (x86_64 or arm64)
  * Node.js 18 or newer        check with:  node --version
  * A browser with WebGL 2 and hardware acceleration enabled
    (Firefox, Chrome/Chromium, or Edge)

  Need Node?
    Debian / Ubuntu   sudo apt install nodejs
    Fedora            sudo dnf install nodejs
    Arch              sudo pacman -S nodejs


HOW TO PLAY
-----------
  1. Open a terminal in this folder.
  2. Run:      ./play.sh
     Permission denied?      chmod +x play.sh && ./play.sh
  3. Your browser opens at http://127.0.0.1:7431/ and the game starts.
  4. Stop it with Ctrl+C in that terminal.


IF IT DOES NOT WORK
-------------------
"Node.js is required"
    Install Node 18+ and run ./play.sh again.

"The browser opened but the screen is black"
    WebGL 2 is not available in that browser. Test it at
    https://get.webgl.org/webgl2/ . Usual fixes: enable hardware acceleration
    in the browser settings, update the graphics driver, and make sure this is
    not a remote/VM session without GPU passthrough.

    The game shows an on-screen error rather than a silent black screen now,
    so if you see text, read it - it names the cause.

"Port 7431 is already in use"
    It is probably already running: open http://127.0.0.1:7431/
    For another port:        PORT=7432 ./play.sh

play.sh prints the address but no browser opens
    Run it as:  NO_OPEN=1 ./play.sh   and open the address manually.


WHAT IS IN THIS BUILD
---------------------
All seven chapters, the menus, the intelligence archive and the endings.

Honest state of the visuals:
  * The first-person weapon is a real CC0 model (Flat Guns East).
  * Several of the other twelve weapons are still built from primitives.
  * Enemy and squad bodies are blockout geometry, not character models.
  * Everything is stylised low-poly by design; this is a playable prototype,
    not a finished commercial shooter.

The full current state, including what is unfinished, is documented in
docs/03_TECHNICAL_ARCHITECTURE.md in the source repository.


LICENCES
--------
  three.js                        MIT
  Quaternius Ultimate Anim Lib    CC0
  Mixamo Vanguard (Soldier.glb)   Adobe Mixamo asset
  Flat Guns East (akm.glb)        CC0

Full texts are in dist/models/.
